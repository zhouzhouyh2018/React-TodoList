import React from 'react';
import ReactDOM from 'react-dom';
// import TodoList from './TodoList';
import App from './components/App'
import './style.css'
// ReactDOM.render(<TodoList />, document.getElementById('root'));
ReactDOM.render(<App />, document.getElementById('root'));

