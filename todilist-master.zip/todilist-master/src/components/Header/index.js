import React, {Component} from 'react';
import './style.css'
class Header extends Component {
    render() {
        return (
            <header className='header'>
                备忘录
            </header>
        );
    }
}

export default Header;